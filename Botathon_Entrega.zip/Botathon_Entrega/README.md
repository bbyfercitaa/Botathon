# Botathon 2026 — Planificación Asistencial

Proyecto completo: dashboard en Python (Streamlit) + ingesta en Blue Prism para los dos Excel de Planificación Asistencial.

## Contenido

```
Botathon_Entrega/
├── Frontend/
│   ├── app.py                 # Dashboard Streamlit
│   ├── .streamlit/config.toml # Tema y puerto
│   └── data/                  # Datos que lee el dashboard
│       ├── base_contratos.csv
│       ├── dotacion_asistencial.csv
│       ├── excepciones.csv
│       └── lop.csv
├── Blueprism/
│   ├── entrega/               # Paquete portable de Blue Prism
│   │   ├── 01_MS_Excel_VBO.xml
│   │   ├── 02_Ingesta_BaseContratos.xml
│   │   ├── 03_Ingesta_Planificacion.xml
│   │   ├── importar.ps1
│   │   ├── convertir_a_csv.py
│   │   └── generar_csv_desde_fuente.py
│   ├── PROCESOS_NAC.md
│   └── GUIA_EXCEL_BLUEPRISM.md
├── Recursos/                  # Excel originales y documento del desafío
├── requirements.txt
├── run.bat
├── run.ps1
└── actualizar_datos.bat
```

## Inicio rápido (Windows)

1. Instala **Python 3.10 o superior**.
2. Doble clic en `run.bat`.

El script crea el entorno virtual, instala las dependencias y abre el dashboard en `http://localhost:8501`.

### Manual

```powershell
python -m venv Frontend\.venv
Frontend\.venv\Scripts\python.exe -m pip install -r requirements.txt
Frontend\.venv\Scripts\streamlit.exe run Frontend\app.py
```

## Datos

El dashboard lee los CSV de `Frontend/data`. Para regenerarlos desde los Excel originales (con fechas correctas):

```powershell
Frontend\.venv\Scripts\python.exe Blueprism\entrega\generar_csv_desde_fuente.py
```

O doble clic en `actualizar_datos.bat`.

Los archivos que espera el dashboard:

| Archivo | Contenido |
|---|---|
| `base_contratos.csv` | Dotación/contratos BUK |
| `dotacion_asistencial.csv` | Planificación por profesional |
| `excepciones.csv` | Excepciones manuales |
| `lop.csv` | Atenciones LOP por instituto |

## Blue Prism

En `Blueprism/entrega` está el paquete importable:

```powershell
cd Blueprism\entrega
.\importar.ps1 -User "tu_usuario" -Password "tu_clave"
```

Requiere Blue Prism 7.x, Excel instalado y un Resource PC. Los procesos dejan XLSX en `Frontend/data`; luego ejecuta `convertir_a_csv.py` o el generador de respaldo.

Detalles en `Blueprism/entrega/README.md` y `Blueprism/PROCESOS_NAC.md`.

## Qué muestra el dashboard

- KPIs: atenciones planificadas, Meta de Gestión 90 %, % FOJA, profesionales y horas directas/indirectas/NAS.
- Filtros por instituto, cargo, área, contrato y profesional.
- Meta por instituto, reparto de horas y evolución mensual.
- Pestaña **Contratos** con la base BUK.
- Pestaña **Ingesta** con el estado de los archivos.

## Notas

- No se incluyen credenciales ni el `.venv`.
- Si Blue Prism actualiza los datos, pulsa **Recargar datos** en la barra lateral.
- El proceso de planificación es pesado (205 columnas); si falla por memoria, usa `generar_csv_desde_fuente.py`.
- Los datos son ficticios, generados para la Botathon 2026.
