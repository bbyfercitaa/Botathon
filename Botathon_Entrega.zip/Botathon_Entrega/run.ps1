$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$python = "python"
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $python = "py"
    } else {
        throw "Instala Python 3.10 o superior desde https://www.python.org/downloads/"
    }
}

if (-not (Test-Path "Frontend\.venv\Scripts\python.exe")) {
    Write-Host "Creando entorno virtual..."
    & $python -m venv "Frontend\.venv"
    & "Frontend\.venv\Scripts\python.exe" -m pip install --upgrade pip
    & "Frontend\.venv\Scripts\python.exe" -m pip install -r "requirements.txt"
}

Write-Host ""
Write-Host "Iniciando dashboard en http://localhost:8501 ..."
Write-Host ""
Push-Location "Frontend"
try {
    & ".venv\Scripts\streamlit.exe" run "app.py"
} finally {
    Pop-Location
}
