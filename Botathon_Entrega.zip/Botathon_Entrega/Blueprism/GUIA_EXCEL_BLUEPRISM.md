# Conectar Excel con Blue Prism: proceso + colecciones

> Ejemplo práctico usando `Botathon/Recursos/Excel prueba.xlsx`.
> Objetivo: leer la hoja **Dotación**, dejarla en una **Collection**, validarla y escribir un CSV limpio que el frontend de Streamlit ya sabe leer.

---

## 1. El modelo mental (3 conceptos y ya)

| Concepto | Qué es | En este ejemplo |
|---|---|---|
| **Process** | El "programa" que orquesta pasos. Tiene una página `Main` y stages: Start, Action, Decision, Loop, Calculation, End. | `Cargar_Dotacion_BUK` |
| **Object (VBO)** | Una caja de herramientas reutilizable (una o varias páginas con Inputs/Outputs). No se ejecuta solo: el proceso lo llama. | `MS Excel VBO` (viene con Blue Prism) |
| **Collection** | Una tabla en memoria, como un `DataTable` o un DataFrame. Tiene campos (columnas) y filas. | `cDotacion` |

Un **Data Item** es una variable (`vRuta`, `vHandle`, `cDotacion`...). Por convención en Blue Prism se les pone prefijo: `v` variable simple, `c` collection, `f` flag, `n` número, `d` fecha.

> Regla de oro: **el proceso no "habla" con Excel directamente**. El proceso llama acciones del `MS Excel VBO`, y el VBO es el que usa Excel por debajo (COM/Interop).

---

## 2. El Excel que vamos a leer

Archivo: `C:\Users\Miau\Desktop\Botathon\Recursos\Excel prueba.xlsx`

- Hoja de datos: **`Dotación`** (con tilde).
- Hoja **`Nota`**: no sirve para el proceso, hay que ignorarla.
- 12 filas de datos + 1 fila de encabezados.

Columnas:

| Columna | Ejemplo | Tipo esperado |
|---|---|---|
| `ID` | PROF-0001 | Texto |
| `Nombre` | Camila | Texto |
| `Apellido` | Rojas Fuentes | Texto |
| `Instituto` | Arica | Texto |
| `Cargo` | Kinesiólogo | Texto |
| `Área` | Rehabilitación | Texto |
| `Tipo de contrato` | Indefinido | Texto |
| `Fecha de ingreso` | 14/03/2022 | Fecha |
| `Horas semanales` | 44 | Número |
| `Estado` | Activo | Texto |

⚠️ **Ojo con los encabezados**: el VBO usa la fila de encabezados como **nombres de campo** de la colección. Nombres con espacios (`Tipo de contrato`), tildes (`Área`) o símbolos funcionan, pero son incómodos en expresiones. Dos opciones:

1. **Recomendada**: normalizar los encabezados en el Excel de origen a `profesional_id, nombre, apellido, instituto, cargo, area, tipo_contrato, fecha_ingreso, horas_semanales, estado`.
2. Normalizar dentro de Blue Prism (sección 6 de esta guía).

Para el ejemplo voy a asumir la opción 2 (no tocar el archivo original) y muestro ambos caminos.

---

## 3. El objeto: `MS Excel VBO`

En Blue Prism: **Objects → Business Objects → MS Excel VBO**. Si no aparece, hay que importar el VBO desde el release/portal de Blue Prism.

Acciones que vamos a usar (los nombres exactos pueden variar un poco según la versión del VBO; el Action stage te muestra los Inputs reales):

| Acción | Inputs | Output | Para qué |
|---|---|---|---|
| `Create Instance` | — | `Handle` | Abre una instancia de Excel en memoria |
| `Open Workbook` | `Handle`, `Workbook Name`, `Read Only` | — | Abre el `.xlsx` |
| `Get Worksheet As Collection` | `Handle`, `Worksheet Name`, `First Row Contains Headers` | `Collection` | **La acción clave**: hoja → colección |
| `Get Worksheet Range As Collection` | `Handle`, `Worksheet Name`, `Range`, `First Row Contains Headers` | `Collection` | Igual, pero para un rango (`A1:J13`) |
| `Write Collection to Worksheet` | `Handle`, `Worksheet Name`, `Collection` | — | Colección → hoja (útil para dejar una "salida" en Excel) |
| `Close Workbook` | `Handle` | — | Cierra el libro |
| `Cleanup` | `Handle` | — | Libera la instancia y **mata el proceso de Excel** |

**Requisito**: el `MS Excel VBO` usa Excel por COM, así que **Excel debe estar instalado** en la máquina donde corre el proceso (el Resource PC), no solo en tu equipo de diseño.

---

## 4. El proceso `Cargar_Dotacion_BUK`

### 4.1 Data Items a crear

| Nombre | Tipo | Valor inicial | Uso |
|---|---|---|---|
| `vRuta` | Text | `C:\Users\Miau\Desktop\Botathon\Recursos\Excel prueba.xlsx` | Ruta del archivo |
| `vHoja` | Text | `Dotación` | Nombre de la hoja |
| `vHandle` | Number | 0 | Handle de la instancia de Excel |
| `vWorkbook` | Text | (vacío) | Nombre del libro que devuelve `Open Workbook` |
| `cDotacion` | Collection | — | Resultado de la lectura (campos dinámicos) |
| `vTotal` | Number | 0 | Filas recorridas |
| `vValidas` | Number | 0 | Filas con `ID` |
| `vErrores` | Number | 0 | Filas sin `ID` |

`cDotacion` **no necesita declarar campos**: el VBO los crea a partir de la primera fila del Excel (`ID`, `Nombre`, `Apellido`, ...). Por eso se accede como `[cDotacion.ID]`, `[cDotacion.Nombre]`, etc.

### 4.2 Stages, en orden

```
[Start]
   ↓
[Action] MS Excel VBO - Create Instance          → vHandle
   ↓
[Action] MS Excel VBO - Open Workbook            (vHandle, vRuta)
                                                  → vWorkbook
   ↓
[Action] MS Excel VBO - Get Worksheet As Collection
         (vHandle, vWorkbook, vHoja)              → cDotacion
   ↓
[Loop] sobre cDotacion
   ├── [Calculation] vTotal = vTotal + 1
   └── [Decision] ¿Len([cDotacion.ID]) > 0?
         ├── Sí → [Calculation] vValidas = vValidas + 1
         └── No → [Calculation] vErrores = vErrores + 1
   ↓
[Action] MS Excel VBO - Close Workbook   (vHandle, vWorkbook, False)
   ↓
[Action] MS Excel VBO - Release Instance (vHandle)
   ↓
[End]
```

> El `LoopStart`/`LoopEnd` de Blue Prism recorre la colección y deja **la fila actual** en el mismo data item `cDotacion`. Por eso dentro del loop se usa `[cDotacion.Campo]`, no un `cFila` aparte.
>
> Si la colección viene vacía, el loop no ejecuta el cuerpo y sigue directo por la salida del `LoopEnd`. Así no hace falta preguntar por la cantidad de filas.

### 4.2.1 Ojo con `Rows.Count`

En Blue Prism 7.5 la expresión `[cDotacion.Rows.Count]` **no existe** y falla en tiempo de ejecución:

```
ERROR: Internal : The field 'Rows' doesn't exist within this collection
```

Para contar filas tienes dos caminos:

1. **Contar dentro del loop** (lo que hace este proceso): `vTotal = vTotal + 1` en cada vuelta.
2. Usar el objeto interno **Collections → `Count Rows`**, que devuelve un output `count`.

### 4.3 Expresiones concretas

**Condición de fila válida** (Decision stage):

```vb
Len([cDotacion.ID]) > 0
```

Si quieres validar más columnas:

```vb
Len([cDotacion.ID]) > 0
And Len([cDotacion.Instituto]) > 0
And ToNumber([cDotacion.Horas semanales]) > 0
```

**Línea CSV** (opcional, si luego agregas la escritura a archivo):

```vb
[vLinea] = [cDotacion.ID] & "," &
           [cDotacion.Nombre] & "," &
           [cDotacion.Apellido] & "," &
           [cDotacion.Instituto] & "," &
           [cDotacion.Cargo] & "," &
           [cDotacion.Área] & "," &
           [cDotacion.Tipo de contrato] & "," &
           [cDotacion.Fecha de ingreso] & "," &
           [cDotacion.Horas semanales] & "," &
           [cDotacion.Estado]
```

Los campos con espacios o tildes (`Tipo de contrato`, `Área`) se usan tal cual, entre corchetes. Si prefieres evitarlos, normaliza los encabezados en el Excel de origen a `tipo_contrato`, `area`, etc.

> Los campos con comas dentro del valor rompen el CSV. Para el MVP alcanza con datos controlados; si quieres robustez, envuelve cada campo entre comillas dobles y duplica las comillas internas.

### 4.4 Normalizar campos con `Collection Manipulation`

Si prefieres dejar los nombres limpios sin tocar el Excel:

1. `Get Worksheet As Collection` → `cDotacion` (campos con espacios/tildes).
2. Action `Utility - Collection Manipulation → Add Field` para crear `cDotacionLimpia` con los campos nuevos.
3. Loop sobre `cDotacion`, y en cada fila asignar:
   ```vb
   [cFilaLimpia.profesional_id] = [cDotacion.ID]
   [cFilaLimpia.tipo_contrato]  = [cDotacion.Tipo de contrato]
   [cFilaLimpia.horas_semanales]= ToNumber([cDotacion.Horas semanales])
   ```
4. `Add Row` a `cDotacionLimpia` con `Collection Manipulation → Add Row` (o un `Collection` stage).

Es más trabajo, pero deja el contrato de datos estable aunque cambie el Excel.

---

## 5. Escribir la salida

Tienes dos caminos:

### A) CSV para el frontend (recomendado en la Botathon)

Action `Utility - File Management → Append Text File` con `vSalidaCSV` y `vLinea`.

- Antes del loop, borra el archivo si existe (`Check File Exists` + `Delete File`) y escribe el encabezado una sola vez.
- Para 600+ filas, `Append Text File` fila a fila funciona pero es lento; si notas lentitud, acumula en bloques de 100 líneas y escribe por bloques.

Encabezado esperado por el frontend (`Frontend/data/profesionales.csv`):

```csv
profesional_id,instituto,cargo,area,tipo_contrato,fecha_inicio,fecha_termino,estado,titular_id
```

### B) Dejarlo en otra hoja de Excel

Action `MS Excel VBO → Write Collection to Worksheet`:

1. `Open Workbook` (o crea un libro nuevo con `Create Workbook`).
2. `Write Collection to Worksheet` con `Handle`, `Salida`, `cDotacionLimpia`.
3. `Save Workbook As` → `dotacion_normalizada.xlsx`.
4. `Close Workbook` + `Cleanup`.

Útil para que el equipo de negocio revise, pero el CSV es mejor para el dashboard.

---

## 6. Fechas y números: el detalle que siempre falla

`Get Worksheet As Collection` devuelve los valores **como texto tal como se ven en la celda**. Eso significa:

- `44` puede llegar como `"44"` → conviértelo con `ToNumber(...)` antes de calcular.
- `14/03/2022` llega como `"14/03/2022"` (formato local) → conviértelo con `ToDate(...)` o, mejor, guarda las fechas en el Excel como texto ISO `2022-03-14`.

Recomendación práctica para el MVP:

1. En el Excel de origen, formato de fecha `yyyy-mm-dd`.
2. En Blue Prism, valida con `IsDate(...)` antes de usar el valor.
3. Si una fila no convierte, no la descartes en silencio: súmala a `vErrores` y registra el `ID` en una colección de errores.

---

## 7. Manejo de errores (lo que evita el Excel "zombi")

Un error típico: el proceso falla a mitad de camino y queda un `EXCEL.EXE` colgado con el archivo bloqueado.

Patrón mínimo:

```
[Recover]
   ↓
[Action] Create Instance
[Action] Open Workbook
[Action] Get Worksheet As Collection
   ↓
[Resume]  (camino feliz)
```

Y en **ambos** caminos (éxito y error) ejecutar:

```
[Action] Close Workbook (vHandle)
[Action] Cleanup (vHandle)
```

Además, antes de abrir:

```vb
[vAviso] = "No existe el archivo: " & [vRutaExcel]
```

con un Decision `FileExists([vRutaExcel])` (o `Utility - File Management → Check File Exists`).

---

## 8. Alternativa: leer Excel sin Excel (OLEDB)

Si el Resource PC no tiene Excel instalado, o el archivo es muy grande, puedes leerlo como base de datos:

```
Provider=Microsoft.ACE.OLEDB.12.0;
Data Source=C:\Users\Miau\Desktop\Botathon\Recursos\Excel prueba.xlsx;
Extended Properties="Excel 12.0 Xml;HDR=YES;IMEX=1";
```

```sql
SELECT * FROM [Dotación$]
```

Pros: rápido, no abre Excel, no deja procesos colgados.
Contras: requiere el driver **ACE OLEDB** con la misma arquitectura que Blue Prism; es solo lectura; infiere tipos y a veces devuelve `NULL` en columnas mixtas; el nombre de hoja con tilde/espacios va entre corchetes.

Para la Botathon, el `MS Excel VBO` es el camino estándar y el que conviene mostrar en la demo.

---

## 9. Checklist para probar el ejemplo

- [ ] El proceso arranca sin abrir una ventana de Excel (Read Only = `True`).
- [ ] `vTotal` = **12** (el archivo tiene 12 profesionales).
- [ ] `vValidas` + `vErrores` = `vTotal`.
- [ ] El CSV de salida tiene 12 filas + encabezado.
- [ ] Al terminar, el Administrador de tareas **no** muestra `EXCEL.EXE`.
- [ ] Si renombras la hoja o el archivo, el proceso termina con un mensaje claro (no con un error rojo sin contexto).
- [ ] Los acentos (`Kinesiólogo`, `Ñuñez`) llegan bien al CSV (UTF-8).

---

## 10. Cómo encaja con el resto del MVP

```
BUK (Excel simulado)
        │
        ▼
Blue Prism  ──  lee Excel → colección → valida → escribe CSV
        │
        ▼
Frontend/data/*.csv
        │
        ▼
Streamlit (app.py)  ──  solo lee y muestra
```

Esto respeta el principio del proyecto: **Streamlit no contiene lógica de negocio** y **el dashboard no depende de que Blue Prism esté corriendo** para mostrar datos; solo consume lo que el bot dejó escrito.

---

## 11. Estado en este entorno (ya creado)

El proceso **ya está importado y publicado** en Blue Prism:

- **Process:** `Cargar_Dotacion_BUK` (publicado).
- **Object:** `MS Excel VBO`.
- XML fuente: `Botathon/Blueprism/Cargar_Dotacion_BUK.xml`.
- **Ejecución verificada:** 12 filas leídas, 12 válidas, 0 errores (sesión `b622b749-8be8-4100-88b3-6ddc2c272803`).

Para verlo: abre Blue Prism → **Processes** → `Cargar_Dotacion_BUK`. Si la app ya estaba abierta, pulsa **F5** para refrescar.

### Lo que encontré al montarlo

1. **El usuario `miau` no existía.** En la base solo estaban `admin` y `mcp`. AutomateC fallaba con "username or password is incorrect" por eso, no por la contraseña. Se corrigió `BP_USER=mcp` en `C:\Users\Miau\blueprism-mcp\.env`.
2. **No había ningún VBO instalado.** La instalación solo tenía dos procesos de prueba. Se importó el `MS Excel VBO` (copia pública de la comunidad: `github.com/BMWRPA/Blueprism`). Es el VBO clásico, con páginas extra que no se usan.
3. **No hay Microsoft Excel instalado en este equipo** (solo LibreOffice). El `MS Excel VBO` funciona por COM, así que el proceso **se ve y se edita, pero al ejecutarlo fallará en `Create Instance`** hasta que instales Excel o lo corras en un equipo que lo tenga.

### Acciones del VBO importado (firmas reales)

| Acción | Inputs | Output |
|---|---|---|
| `Create Instance` | `Enable Events` (flag) | `handle` (number) |
| `Open Workbook` | `handle`, `File name` | `Workbook Name` (text) |
| `Get Worksheet As Collection` | `handle`, `Workbook Name`, `Worksheet Name` | `Data` (collection) |
| `Close Workbook` | `handle`, `Workbook Name`, `Save Data` (flag) | — |
| `Release Instance` | `handle` | — |

> Este VBO **no** tiene el input "First Row Contains Headers": siempre usa la primera fila como encabezados y crea los campos de la colección con ese texto exacto.

### Cómo ejecutarlo cuando haya Excel

1. Que el Resource PC tenga Excel instalado.
2. Publicar el proceso (ya está publicado).
3. En Control Room, ejecutar `Cargar_Dotacion_BUK` en un recurso.
4. Revisar `vTotal`, `vValidas` y `vErrores` en el log de la sesión.

### Si no quieres depender de Excel

Alternativas para la Botathon:

- **LibreOffice headless** ya está instalado: convertir el `.xlsx` a `.csv` y que Blue Prism lea el CSV.
- **Leer el `.xlsx` como ZIP + XML** en un Code stage (sin Excel ni drivers).
- **Instalar el driver ACE OLEDB** y leer con SQL.

Ninguna de esas usa el `MS Excel VBO`; son caminos distintos que puedo montar si el equipo no va a tener Excel.
