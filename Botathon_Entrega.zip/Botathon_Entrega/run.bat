@echo off
setlocal
cd /d "%~dp0"

set "PY=python"
where python >nul 2>nul
if errorlevel 1 (
    where py >nul 2>nul
    if errorlevel 1 goto :nopython
    set "PY=py -3"
)

if not exist "Frontend\.venv\Scripts\python.exe" (
    echo Creando entorno virtual...
    %PY% -m venv "Frontend\.venv"
    if errorlevel 1 goto :error
    "Frontend\.venv\Scripts\python.exe" -m pip install --upgrade pip
    "Frontend\.venv\Scripts\python.exe" -m pip install -r "requirements.txt"
    if errorlevel 1 goto :error
)

echo.
echo Iniciando dashboard en http://localhost:8501 ...
echo.
pushd "Frontend"
".venv\Scripts\streamlit.exe" run "app.py"
popd
goto :eof

:nopython
echo.
echo No se encontro Python. Instala Python 3.10 o superior:
echo https://www.python.org/downloads/
echo.
pause
exit /b 1

:error
echo.
echo Ocurrio un error preparando el entorno.
echo.
pause
exit /b 1
