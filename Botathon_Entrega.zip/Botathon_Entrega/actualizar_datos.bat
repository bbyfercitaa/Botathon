@echo off
setlocal
cd /d "%~dp0"

if not exist "Frontend\.venv\Scripts\python.exe" (
    echo Primero ejecuta run.bat para crear el entorno.
    pause
    exit /b 1
)

echo Regenerando CSV desde los Excel originales...
"Frontend\.venv\Scripts\python.exe" "Blueprism\entrega\generar_csv_desde_fuente.py" --base "Recursos\Nac - Base contratos x mes.xlsx" --plan "Recursos\Nac - Planificación Asistencial x mes.xlsx" --out "Frontend\data"

echo.
echo Datos actualizados en Frontend\data.
pause
