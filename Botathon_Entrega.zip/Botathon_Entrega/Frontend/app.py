﻿# AQUÍ SE EDITA EL DASHBOARD
# ============================================================
# 1. IMPORTACIONES Y CONFIGURACIÓN DE LA PÁGINA
# ============================================================

# Path: construye rutas de archivos de forma segura.
# datetime: para leer fechas de modificación de los archivos.
# pandas: lectura/transformación de datos.
# streamlit: interfaz.
import datetime as dt
from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Planificación Asistencial",
    page_icon="📊",
    layout="wide",
)

# Carpeta donde los procesos de Blue Prism dejan sus salidas.
# También es la carpeta que usa el frontend para los CSV.
DATA_DIR = Path(__file__).resolve().parent / "data"


# ============================================================
# 2. CARGA DE DATOS DESDE BLUE PRISM
# ============================================================

# Los procesos de Blue Prism dejan XLSX; el conversor deja CSV.
# Damos prioridad al CSV (UTF-8, fechas limpias) y, si no existe,
# leemos el XLSX que generó Blue Prism directamente.
@st.cache_data(ttl=30)
def cargar_tabla(nombre: str) -> tuple[pd.DataFrame, Path | None]:
    csv = DATA_DIR / f"{nombre}.csv"
    xlsx = DATA_DIR / f"{nombre}.xlsx"

    if csv.exists() and csv.stat().st_size > 0:
        return pd.read_csv(csv, encoding="utf-8-sig"), csv
    if xlsx.exists() and xlsx.stat().st_size > 0:
        return pd.read_excel(xlsx), xlsx
    return pd.DataFrame(), None


def horas_desde_valor(valor) -> float:
    """Convierte '1 days 06:00:00', '06:00:00' o un número a horas."""
    if valor is None or (isinstance(valor, float) and pd.isna(valor)):
        return 0.0
    if isinstance(valor, (int, float)):
        return float(valor)
    if isinstance(valor, dt.time):
        return valor.hour + valor.minute / 60 + valor.second / 3600
    if isinstance(valor, dt.timedelta):
        return valor.total_seconds() / 3600
    try:
        return pd.to_timedelta(str(valor)).total_seconds() / 3600
    except Exception:
        return 0.0


def preparar_dotacion(df: pd.DataFrame) -> pd.DataFrame:
    """Normaliza la tabla principal que genera Ingesta_Planificacion."""
    df = df.copy()

    # Nombres amigables: Instituto completo (División) y área descriptiva.
    if "División" in df.columns:
        df["Instituto"] = df["División"].fillna(df.get("Instituto", "Sin dato"))
    for col in ["Instituto", "Cargo", "Area", "Tipo de Contrato"]:
        if col in df.columns:
            df[col] = df[col].fillna("Sin dato").astype(str).str.strip()
    if "Decripcion C.Costo" in df.columns:
        df["AreaMostrada"] = df["Decripcion C.Costo"].fillna(df.get("Area", "Sin dato"))
    else:
        df["AreaMostrada"] = df.get("Area", "Sin dato")

    # Identificador como texto, sin el .0 que agrega pandas.
    if "PersonaId" in df.columns:
        df["PersonaId"] = (
            df["PersonaId"].astype(str).str.replace(r"\.0$", "", regex=True)
        )

    # Horas semanales y su reparto directo / indirecto / NAS.
    df["horas_semana"] = pd.to_numeric(
        df.get("Prom_Pond Horas Semanales"), errors="coerce"
    ).fillna(0)
    df["horas_directas"] = df.get("H/Sem Disp.Ate", pd.Series(dtype=object)).map(
        horas_desde_valor
    )
    df["horas_nas"] = pd.to_numeric(
        df.get("H/Sem NAS Total"), errors="coerce"
    ).fillna(0)
    df["horas_indirectas"] = (
        df["horas_semana"] - df["horas_directas"] - df["horas_nas"]
    ).clip(lower=0)

    # Métricas anuales que ya calcula el Excel de planificación.
    df["plan_anual"] = pd.to_numeric(
        df.get("Plan_Total Atenciones por Año"), errors="coerce"
    ).fillna(0)
    df["meta_anual"] = pd.to_numeric(
        df.get("MG_Total Atenciones por Año"), errors="coerce"
    ).fillna(0)

    # % FOJA = horas disponibles para atención directa / horas contratadas.
    df["foja"] = (df["horas_directas"] / df["horas_semana"]).where(
        df["horas_semana"] > 0, 0.0
    )

    return df


dotacion, ruta_dotacion = cargar_tabla("dotacion_asistencial")
base_contratos, ruta_base = cargar_tabla("base_contratos")
excepciones, ruta_exc = cargar_tabla("excepciones")
lop, ruta_lop = cargar_tabla("lop")

if dotacion.empty:
    st.error(
        "No encuentro `dotacion_asistencial.csv` ni `.xlsx` en `Frontend/data`.\n\n"
        "Ejecuta `Ingesta_Planificacion` en Blue Prism o el respaldo:\n"
        "`python ..\\Blueprism\\entrega\\generar_csv_desde_fuente.py`"
    )
    st.stop()

dotacion = preparar_dotacion(dotacion)


# ============================================================
# 3. FUNCIONES AUXILIARES
# ============================================================

def fmt(numero) -> str:
    return f"{numero:,.0f}".replace(",", ".")


def fmt_decimal(numero) -> str:
    """Formato chileno: miles con punto y decimales con coma."""
    return f"{numero:,.1f}".replace(",", "X").replace(".", ",").replace("X", ".")


def opciones(df: pd.DataFrame, columna: str) -> list[str]:
    if columna not in df.columns:
        return ["Todos"]
    valores = sorted(df[columna].dropna().astype(str).unique().tolist())
    return ["Todos"] + valores


def archivo_info(nombre: str, ruta: Path | None, df: pd.DataFrame) -> dict:
    if ruta is None or df.empty:
        return {
            "Archivo": nombre,
            "Estado": "No encontrado",
            "Filas": 0,
            "Columnas": 0,
            "Modificado": "",
        }
    return {
        "Archivo": ruta.name,
        "Estado": "OK",
        "Filas": len(df),
        "Columnas": len(df.columns),
        "Modificado": dt.datetime.fromtimestamp(ruta.stat().st_mtime).strftime(
            "%Y-%m-%d %H:%M"
        ),
    }


# ============================================================
# 4. ENCABEZADO
# ============================================================

st.title("Planificación Asistencial Teletón")
st.caption(
    "MVP Botathon 2026 · Ingesta NAC (Blue Prism / respaldo) · "
    f"actualizado {dt.datetime.fromtimestamp(ruta_dotacion.stat().st_mtime).strftime('%Y-%m-%d %H:%M') if ruta_dotacion else 's/f'}"
)


# ============================================================
# 5. BARRA LATERAL: FILTROS EN CASCADA
# ============================================================

with st.sidebar:
    st.header("Filtros")

    if st.button("Recargar datos"):
        st.cache_data.clear()
        st.rerun()

    instituto = st.selectbox("Instituto", opciones(dotacion, "Instituto"))
    filtrado = (
        dotacion
        if instituto == "Todos"
        else dotacion[dotacion["Instituto"] == instituto]
    )

    cargo = st.selectbox("Cargo", opciones(filtrado, "Cargo"))
    filtrado = filtrado if cargo == "Todos" else filtrado[filtrado["Cargo"] == cargo]

    area = st.selectbox("Área", opciones(filtrado, "AreaMostrada"))
    filtrado = (
        filtrado if area == "Todos" else filtrado[filtrado["AreaMostrada"] == area]
    )

    contrato = st.selectbox("Tipo de contrato", opciones(filtrado, "Tipo de Contrato"))
    filtrado = (
        filtrado
        if contrato == "Todos"
        else filtrado[filtrado["Tipo de Contrato"] == contrato]
    )

    profesional = st.selectbox("Profesional (PersonaId)", opciones(filtrado, "PersonaId"))
    filtrado = (
        filtrado
        if profesional == "Todos"
        else filtrado[filtrado["PersonaId"] == profesional]
    )

    st.divider()
    st.caption(f"{len(filtrado)} profesionales seleccionados")

if filtrado.empty:
    st.warning("No hay datos para los filtros seleccionados.")
    st.stop()


# ============================================================
# 6. INDICADORES PRINCIPALES (KPIs)
# ============================================================

total_plan = filtrado["plan_anual"].sum()
total_meta = filtrado["meta_anual"].sum()
horas_semana = filtrado["horas_semana"].sum()
horas_directas = filtrado["horas_directas"].sum()
horas_indirectas = filtrado["horas_indirectas"].sum()
horas_nas = filtrado["horas_nas"].sum()

foja = (horas_directas / horas_semana * 100) if horas_semana else 0.0
n_profesionales = filtrado["PersonaId"].nunique()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Atenciones planificadas", fmt(total_plan))
c2.metric("Meta de Gestión (90%)", fmt(total_meta))
c3.metric("% FOJA", f"{foja:.1f}%")
c4.metric("Profesionales", fmt(n_profesionales))

c5, c6, c7, c8 = st.columns(4)
c5.metric("Horas semanales", fmt(horas_semana))
c6.metric("Horas directas/sem", fmt_decimal(horas_directas))
c7.metric("Horas indirectas/sem", fmt_decimal(horas_indirectas))
c8.metric("Horas NAS/sem", fmt_decimal(horas_nas))

st.caption(
    f"{len(filtrado)} registros · {n_profesionales} profesionales · "
    "Fuente: salidas de Ingesta_BaseContratos e Ingesta_Planificacion."
)


# ============================================================
# 7. PESTAÑAS DEL DASHBOARD
# ============================================================

tab_resumen, tab_detalle, tab_contratos, tab_ingesta = st.tabs(
    ["Resumen", "Detalle", "Contratos", "Ingesta"]
)


# ---- Pestaña Resumen ----
with tab_resumen:
    st.subheader("Meta de Gestión por instituto")

    por_instituto = (
        filtrado.groupby("Instituto", as_index=False)
        .agg(
            plan=("plan_anual", "sum"),
            meta=("meta_anual", "sum"),
            profesionales=("PersonaId", "nunique"),
        )
        .sort_values("meta", ascending=False)
    )
    st.bar_chart(por_instituto, x="Instituto", y="meta")
    st.dataframe(por_instituto, hide_index=True, width="stretch")

    st.subheader("Horas semanales por tipo")
    reparto = pd.DataFrame(
        {
            "Tipo": ["Directas", "Indirectas", "NAS"],
            "Horas semanales": [horas_directas, horas_indirectas, horas_nas],
        }
    )
    st.bar_chart(reparto, x="Tipo", y="Horas semanales")

    st.subheader("Evolución mensual de la Meta de Gestión")
    columnas_mes = [f"MG_AteDir+Ind{i}" for i in range(1, 13)]
    columnas_mes = [c for c in columnas_mes if c in filtrado.columns]
    if columnas_mes:
        meses = [
            "Ene",
            "Feb",
            "Mar",
            "Abr",
            "May",
            "Jun",
            "Jul",
            "Ago",
            "Sep",
            "Oct",
            "Nov",
            "Dic",
        ]
        evolucion = pd.DataFrame(
            {
                "Mes": meses,
                "Meta de Gestión": [
                    pd.to_numeric(filtrado[c], errors="coerce").fillna(0).sum()
                    for c in columnas_mes
                ],
            }
        )
        st.line_chart(evolucion, x="Mes", y="Meta de Gestión")
        st.dataframe(evolucion, hide_index=True, width="stretch")
    else:
        st.info("La tabla de planificación no trae las columnas mensuales esperadas.")


# ---- Pestaña Detalle ----
with tab_detalle:
    st.subheader("Detalle por profesional")

    columnas = [
        "PersonaId",
        "Instituto",
        "Cargo",
        "AreaMostrada",
        "Tipo de Contrato",
        "horas_semana",
        "horas_directas",
        "horas_indirectas",
        "horas_nas",
        "foja",
        "plan_anual",
        "meta_anual",
    ]
    columnas = [c for c in columnas if c in filtrado.columns]
    detalle = filtrado[columnas].copy()
    if "foja" in detalle.columns:
        detalle["foja"] = (detalle["foja"] * 100).round(1)

    st.dataframe(
        detalle.rename(
            columns={
                "AreaMostrada": "Área",
                "horas_semana": "Horas/sem",
                "horas_directas": "Directas/sem",
                "horas_indirectas": "Indirectas/sem",
                "horas_nas": "NAS/sem",
                "foja": "% FOJA",
                "plan_anual": "Plan anual",
                "meta_anual": "Meta 90%",
            }
        ),
        hide_index=True,
        width="stretch",
    )


# ---- Pestaña Contratos ----
with tab_contratos:
    st.subheader("Base de contratos (BUK)")

    if base_contratos.empty:
        st.info(
            "No hay base de contratos. Ejecuta `Ingesta_BaseContratos` "
            "o el respaldo `generar_csv_desde_fuente.py`."
        )
    else:
        bc = base_contratos.copy()
        for col in ["IT", "Instituto", "Cargo", "Tipo de Contrato", "Periodo"]:
            if col in bc.columns:
                bc[col] = bc[col].astype(str).str.strip()
        if "PersonaId" in bc.columns:
            bc["PersonaId"] = (
                bc["PersonaId"].astype(str).str.replace(r"\.0$", "", regex=True)
            )

        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Registros", fmt(len(bc)))
        k2.metric(
            "Profesionales",
            fmt(bc["PersonaId"].nunique() if "PersonaId" in bc.columns else 0),
        )
        k3.metric(
            "Institutos",
            fmt(bc["Instituto"].nunique() if "Instituto" in bc.columns else 0),
        )
        k4.metric(
            "Períodos",
            fmt(bc["Periodo"].nunique() if "Periodo" in bc.columns else 0),
        )

        if "Periodo" in bc.columns:
            por_periodo = bc.groupby("Periodo").size().reset_index(name="Registros")
            st.bar_chart(por_periodo, x="Periodo", y="Registros")

        columnas_bc = [
            c
            for c in [
                "IT",
                "Instituto",
                "PersonaId",
                "Periodo",
                "Cargo",
                "Tipo de Contrato",
                "Horas Semanales",
                "Fecha Ingreso Compañía",
            ]
            if c in bc.columns
        ]
        st.dataframe(
            bc[columnas_bc].head(500), hide_index=True, width="stretch"
        )
        st.caption(
            f"{len(bc)} registros. Mostrando hasta 500. "
            f"Fuente: {ruta_base.name if ruta_base else 's/f'}."
        )


# ---- Pestaña Ingesta ----
with tab_ingesta:
    st.subheader("Estado de la ingesta Blue Prism")

    estado = pd.DataFrame(
        [
            archivo_info("dotacion_asistencial", ruta_dotacion, dotacion),
            archivo_info("base_contratos", ruta_base, base_contratos),
            archivo_info("excepciones", ruta_exc, excepciones),
            archivo_info("lop", ruta_lop, lop),
        ]
    )
    st.dataframe(estado, hide_index=True, width="stretch")

    st.caption(
        "Salidas de `Ingesta_BaseContratos` e `Ingesta_Planificacion`. "
        "Si un archivo no aparece, ejecuta el proceso en Blue Prism o el respaldo "
        "`generar_csv_desde_fuente.py`."
    )

    st.subheader("Excepciones")
    if excepciones.empty:
        st.info("Sin excepciones cargadas.")
    else:
        st.dataframe(excepciones, hide_index=True, width="stretch")

    st.subheader("LOP por instituto")
    if lop.empty:
        st.info("Sin datos LOP.")
    else:
        st.dataframe(lop, hide_index=True, width="stretch")

    errores_csv = DATA_DIR / "errores_ingesta.csv"
    if errores_csv.exists():
        st.subheader("Errores de ingesta")
        st.dataframe(
            pd.read_csv(errores_csv), hide_index=True, width="stretch"
        )
